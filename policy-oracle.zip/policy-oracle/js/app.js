/* ===== MAIN APP - ROUTER & INITIALIZATION ===== */
(function() {
  const content = document.getElementById('page-content');
  const navLinks = document.querySelectorAll('.nav-link');
  const mobileLinks = document.querySelectorAll('.mobile-link');
  const mobileMenu = document.getElementById('mobile-menu');
  const navToggle = document.getElementById('nav-toggle');
  let currentPage = '';

  // Route map
  const routes = {
    home: Pages.home,
    about: Pages.about,
    services: Pages.services,
    insights: Pages.insights,
    catalogue: Pages.catalogue,
    blog: Pages.blog,
    team: Pages.team,
    contact: Pages.contact
  };

  // Navigate to page
  function navigate(page) {
    if (page === currentPage) return;
    currentPage = page;

    // Update nav active state
    navLinks.forEach(l => {
      l.classList.toggle('active', l.getAttribute('href') === '#' + page);
    });

    // Close mobile menu
    closeMobileMenu();

    // Page transition
    content.classList.remove('page-transition-active');
    content.classList.add('page-transition-enter');

    setTimeout(() => {
      // Render page
      const render = routes[page];
      content.innerHTML = render ? render() : Pages.home();

      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'instant' });

      // Animate in
      requestAnimationFrame(() => {
        content.classList.remove('page-transition-enter');
        content.classList.add('page-transition-active');
      });

      // Re-bind data-link clicks inside new content
      bindContentLinks();

      // Run animations
      setTimeout(() => Animations.runPageAnimations(), 50);
    }, 200);
  }

  // Bind click handlers on [data-link] elements
  function bindContentLinks() {
    content.querySelectorAll('[data-link]').forEach(link => {
      link.addEventListener('click', handleLinkClick);
    });
  }

  function handleLinkClick(e) {
    const href = this.getAttribute('href');
    const modalData = this.getAttribute('data-modal');
    
    if (modalData) {
      e.preventDefault();
      openModal(modalData);
      return;
    }
    
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const page = href.slice(1) || 'home';
      window.location.hash = page;
    }
  }

  // Modal logic
  const modal = document.getElementById('global-modal');
  const modalOverlay = modal.querySelector('.modal-overlay');
  const modalClose = modal.querySelector('.modal-close');
  const modalBody = document.getElementById('modal-body');

  const modalContentMap = {
    'policy-design': '<h3>Public & Social Policy Design</h3><p>We believe that policy should be driven by the people it affects. Our human-centred policy design framework ensures that lived experiences are embedded into the policy process.</p><ul><li>Stakeholder mapping and engagement</li><li>Evidence collection and priority mapping</li><li>Impact assessment and feasibility studies</li><li>Sustainable intervention design</li></ul>',
    'tech-policy': '<h3>AI and Tech Policy</h3><p>As Africa digitizes, organizations must navigate complex technological landscapes responsibly. We help draft actionable, forward-looking tech policies.</p><ul><li>AI governance frameworks and maturity models</li><li>Data ethics and responsible innovation guidelines</li><li>Digital transformation strategy built for the African context</li><li>Compliance with evolving regional tech regulations</li></ul>',
    'capacity-building': '<h3>Leadership & Capacity Building</h3><p>Strong policies require strong leaders. Our executive training programmes are designed to upskill public and private sector teams for today’s governance challenges.</p><ul><li>Executive coaching and leadership transitions</li><li>Systems thinking for complex problem solving</li><li>Negotiation and conflict resolution in public service</li><li>Data-driven decision making masterclasses</li></ul>',
    'research': '<h3>Policy Research, Analysis & Review</h3><p>Robust evidence is the foundation of good policy. We provide deep-dive evaluations to ensure your initiatives are aligned with best practices.</p><ul><li>Comprehensive policy evaluation and reform recommendations</li><li>Addressing needs of marginalized and overlooked populations</li><li>Alignment with emerging global trends and SDGs</li></ul>',
    'climate': '<h3>Climate Policy & Governance</h3><p>Climate change requires resilient strategies. We help governments and enterprises integrate climate considerations into their core operations.</p><ul><li>Climate risk assessments and management strategies</li><li>Resilience building and adaptation policies</li><li>Enterprise risk framework integration</li></ul>',
    'urban': '<h3>Urban Policy & Development Planning</h3><p>Rapid urbanization demands resilient infrastructure. We support inclusive growth through strategic urban planning.</p><ul><li>Responsive infrastructure design and planning</li><li>Needs forecasting and demographic modeling</li><li>Community-engaged urban storytelling</li></ul>',
    'knowledge': '<h3>Knowledge Systems</h3><p>Organizational knowledge is a critical asset. We build systems that make information accessible, secure, and actionable.</p><ul><li>AI-powered internal knowledge management systems</li><li>Policy documentation and content creation templates</li><li>Ecosystem strategies for knowledge sharing</li></ul>'
  };

  function openModal(type) {
    if (modalContentMap[type]) {
      modalBody.innerHTML = modalContentMap[type];
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal() {
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }

  modalClose.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', closeModal);

  // Mobile menu
  function closeMobileMenu() {
    mobileMenu.classList.remove('open');
    navToggle.classList.remove('active');
    document.body.style.overflow = '';
  }

  navToggle.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.toggle('open');
    navToggle.classList.toggle('active');
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  // Bind all static nav links
  document.querySelectorAll('[data-link]').forEach(link => {
    link.addEventListener('click', handleLinkClick);
  });

  // Hash change routing
  window.addEventListener('hashchange', () => {
    const page = window.location.hash.slice(1) || 'home';
    navigate(page);
  });

  // Preloader
  function hidePreloader() {
    const preloader = document.getElementById('preloader');
    setTimeout(() => {
      preloader.classList.add('hidden');
      // Initial page load
      const page = window.location.hash.slice(1) || 'home';
      navigate(page);
    }, 2000);
  }

  // Initialize
  function init() {
    Animations.initCursor();
    Animations.initHeaderScroll();
    hidePreloader();
  }

  // Start when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
