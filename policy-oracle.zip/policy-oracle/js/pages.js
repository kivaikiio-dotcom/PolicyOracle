/* ===== PAGE TEMPLATES ===== */
const Pages = {

home: () => `
<section class="hero">
  <div class="particles" id="hero-particles"></div>
  <div class="container">
    <div class="hero-grid">
      <div class="hero-content">
        <div class="hero-badge reveal"><span class="hero-badge-dot"></span> A Policy Think Tank of Africa</div>
        <h1 class="reveal reveal-delay-1">Your Policy <br>Problems.<br><span class="gold">Our Expertise.</span></h1>
        <p class="hero-text reveal reveal-delay-2">From AI & Tech Policy to Climate Governance — we work with governments, NGOs, and the private sector across East Africa and the SADC region to solve society's most pressing challenges.</p>
        <div class="hero-actions reveal reveal-delay-3">
          <a href="#contact" class="btn-primary" data-link>Engage Us <span>→</span></a>
          <a href="#services" class="btn-secondary" data-link>Our Expertise</a>
        </div>
      </div>
      <div class="hero-visual reveal reveal-delay-2">
        <div class="hero-card">
          <div class="hero-card-title">Trusted By</div>
          <p class="hero-card-text">We partner with forward-thinking public and private sector clients.</p>
          <div class="hero-stats" style="grid-template-columns: 1fr; gap: 16px;">
            <div class="hero-stat" style="text-align: left;"><div class="hero-stat-num" style="font-size: 1.5rem;">National Cancer Institute Kenya</div></div>
            <div class="hero-stat" style="text-align: left;"><div class="hero-stat-num" style="font-size: 1.5rem;">Salvation Army Eastern Region</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section section-dark">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">Core Capabilities</div>
      <h2 class="section-title">Our Expertise</h2>
      <p class="section-subtitle">Research, training, and consultancy tailored for the African policy landscape.</p>
    </div>
    <div class="services-grid">
      <div class="service-card reveal reveal-delay-1">
        <div class="service-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
        </div>
        <h3>Policy Design & Development</h3>
        <p>Human-centred policy solutions grounded in rigorous evidence and stakeholder engagement.</p>
        <a href="#" class="service-link" data-link data-modal="policy-design">Learn More →</a>
      </div>
      <div class="service-card reveal reveal-delay-2">
        <div class="service-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
        </div>
        <h3>AI and Tech Policy</h3>
        <p>We help organisations define their artificial intelligence and technology policy frameworks — including AI governance, ethics, and digital transformation strategy.</p>
        <a href="#" class="service-link" data-link data-modal="tech-policy">Learn More →</a>
      </div>
      <div class="service-card reveal reveal-delay-3">
        <div class="service-icon">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
        </div>
        <h3>Leadership & Capacity Building</h3>
        <p>Practical programmes that upskill public and private sector teams for today's governance challenges.</p>
        <a href="#" class="service-link" data-link data-modal="capacity-building">Learn More →</a>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="cta-banner reveal">
      <h2>Ready to <span class="gold">Transform Policy</span>?</h2>
      <p>Partner with us to design, evaluate, and reform policies using deep sector experience and actionable insights.</p>
      <a href="#contact" class="btn-primary" data-link>Engage Us Today →</a>
    </div>
  </div>
</section>
`,

about: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="about-grid">
      <div>
        <div class="section-label reveal">About Us</div>
        <h2 class="section-title reveal reveal-delay-1">A Policy Think Tank <br><span class="gold">of Africa</span></h2>
        <p class="section-subtitle reveal reveal-delay-2" style="max-width:none">Policy Oracle is a leading think tank offering research, training, and consultancy to governments, NGOs, and the private sector across East Africa and the SADC region. Based in Nairobi, Kenya, we specialise in public policy, ESG, AI and Tech Policy, and leadership development.</p>
        <div class="about-features reveal reveal-delay-3">
          <div class="about-feature">
            <div class="about-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            </div>
            <div><h4>Rigorous Research</h4><p>We conduct evidence-based research that informs better policy decisions. From macro-economic modelling to impact evaluations, we turn complex data into actionable insights.</p></div>
          </div>
          <div class="about-feature">
            <div class="about-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
            </div>
            <div><h4>Expert Training</h4><p>Our training programmes equip individuals and institutions with the skills needed to thrive in a rapidly changing policy landscape — delivered on-site or virtually.</p></div>
          </div>
          <div class="about-feature">
            <div class="about-feature-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
            </div>
            <div><h4>Strategic Consultancy</h4><p>We partner with clients to design, evaluate, and reform policies. Our consultants bring deep government and sector experience to every engagement.</p></div>
          </div>
        </div>
      </div>
      <div class="about-image reveal reveal-delay-2">
        <div class="about-image-inner">
          <div class="logo-mark" style="width:80px;height:80px;font-size:2rem;margin:0 auto 20px">PO</div>
          <p class="about-image-quote">"Your Policy Problems.<br>Our Expertise."</p>
        </div>
      </div>
    </div>
  </div>
</section>
`,

services: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">Our Services</div>
      <h2 class="section-title">Policy & <span class="gold">Consultancy</span></h2>
      <p class="section-subtitle">We design effective, sustainable policies through stakeholder engagement, human-centred research, evidence collection, priority mapping, and impact assessment.</p>
    </div>
    <div class="services-grid">
      <div class="service-card reveal reveal-delay-1" style="cursor:pointer" data-link data-modal="policy-design">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/></svg></div>
        <h3>Public & Social Policy Design</h3>
        <p>Human-centred policy solutions grounded in rigorous evidence and stakeholder engagement. We map priorities and design sustainable interventions.</p>
      </div>
      <div class="service-card reveal reveal-delay-2" style="cursor:pointer" data-link data-modal="research">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
        <h3>Policy Research, Analysis & Review</h3>
        <p>We evaluate, review, and reform existing policies, ensuring they align with best practice, emerging trends, and the needs of overlooked populations.</p>
      </div>
      <div class="service-card reveal reveal-delay-3" style="cursor:pointer" data-link data-modal="research">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/></svg></div>
        <h3>Research & Capacity Building</h3>
        <p>Macro-economic modelling, data analytics, competitive intelligence, and forecasting — giving organisations the evidence base to make confident strategic decisions.</p>
      </div>
      <div class="service-card reveal reveal-delay-1" style="cursor:pointer" data-link data-modal="tech-policy">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg></div>
        <h3>AI & Tech Policy</h3>
        <p>We help organisations define their artificial intelligence and technology policy — covering AI governance frameworks, data ethics, responsible innovation, and digital transformation strategy built for Africa.</p>
      </div>
      <div class="service-card reveal reveal-delay-2" style="cursor:pointer" data-link data-modal="climate">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg></div>
        <h3>Climate Policy & Governance</h3>
        <p>Climate risk management, resilience building, and integration of climate considerations into government policy and enterprise risk frameworks.</p>
      </div>
      <div class="service-card reveal reveal-delay-3" style="cursor:pointer" data-link data-modal="urban">
        <div class="service-icon"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
        <h3>Urban Policy & Development Planning</h3>
        <p>Responsive and resilient infrastructure design, infrastructural needs forecasting, and urban storytelling that engages communities and drives inclusive growth.</p>
      </div>
      <div class="service-card reveal reveal-delay-1" style="grid-column: 1 / -1; max-width: 800px; margin: 0 auto; cursor:pointer;" data-link data-modal="knowledge">
        <div class="service-icon" style="margin: 0 auto 24px;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></div>
        <h3 style="text-align: center;">Knowledge Systems</h3>
        <p style="text-align: center;">AI-powered knowledge systems, content creation, templates, and ecosystem strategies that make organisational knowledge accessible and actionable.</p>
      </div>
    </div>
  </div>
</section>
`,

insights: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">Training Programmes</div>
      <h2 class="section-title">Capacity <span class="gold">Building</span></h2>
      <p class="section-subtitle">Our specialised executive training programmes designed for the African public and private sectors.</p>
    </div>
    <div class="insights-grid">
      <div class="insight-card reveal reveal-delay-1">
        <div class="insight-image"><div class="insight-image-overlay">💻</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Tech Policy</span></div>
          <h3>AI Governance & Policy Frameworks</h3>
          <p>Equip your leadership teams to design, implement, and oversee responsible AI governance frameworks aligned with international best practice and African realities.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-2">
        <div class="insight-image"><div class="insight-image-overlay">📜</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Tech Policy</span></div>
          <h3>Developing Organisational AI Policy</h3>
          <p>A hands-on programme guiding organisations through the process of drafting, consulting on, and adopting a practical AI policy.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-3">
        <div class="insight-image"><div class="insight-image-overlay">⚖️</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Tech Policy</span></div>
          <h3>Data Ethics & Responsible Innovation</h3>
          <p>Understand the ethical dimensions of data use, algorithmic decision-making, and build a culture of responsible innovation.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-1">
        <div class="insight-image"><div class="insight-image-overlay">🌱</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">ESG</span></div>
          <h3>Environmental, Social & Governance (ESG)</h3>
          <p>From Level 1 introductory courses on sustainable business to Advanced training on integrating ESG principles into business strategies.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-2">
        <div class="insight-image"><div class="insight-image-overlay">🌍</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Climate</span></div>
          <h3>Climate Science for Policymakers</h3>
          <p>Comprehensive understanding of climate science and its implications for policy development and evidence-based decision-making.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-3">
        <div class="insight-image"><div class="insight-image-overlay">📊</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Policy Design</span></div>
          <h3>Public Policy Formulation & Analysis</h3>
          <p>Strengthening formulation capacity with a focus on policy research, agenda setting, advocacy, and reviewing public policies for technical feasibility.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-1">
        <div class="insight-image"><div class="insight-image-overlay">📈</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Data</span></div>
          <h3>MEAL & Result-Based Monitoring</h3>
          <p>Designing effective monitoring and evaluation frameworks, documenting learning outcomes, and emphasising data-driven decision-making.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-2">
        <div class="insight-image"><div class="insight-image-overlay">🗣️</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Leadership</span></div>
          <h3>Be a Leader, Not a Boss</h3>
          <p>Skills, tools, and mindset to balance growing teams, tasks, and priorities. Covers team building, communication, and motivation.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-3">
        <div class="insight-image"><div class="insight-image-overlay">🤝</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Leadership</span></div>
          <h3>Great Leadership Conversations Means Feedback</h3>
          <p>Develop team leadership skills and unleash team members' potential through structural communication and leadership conversations.</p>
        </div>
      </div>
    </div>
    
    <div class="cta-banner reveal" style="margin-top:60px">
      <h2>Explore <span class="gold">600+ Certifications</span></h2>
      <p>We partner with our sister company, GLI Kenya, to offer fully online, globally recognised certifications alongside our extensive executive training catalogue.</p>
      <a href="#catalogue" class="btn-primary" data-link>View Course Catalogue →</a>
    </div>
  </div>
</section>
`,

catalogue: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">GLI Kenya Partnership</div>
      <h2 class="section-title">Professional <span class="gold">Certifications</span></h2>
      <p class="section-subtitle">Over 600 professional executive programmes and certifications in Policy, Management, Data, and Leadership.</p>
    </div>
    
    <div class="category-filter reveal reveal-delay-1" id="course-filters">
      <button class="filter-btn active" data-filter="all">All</button>
      <button class="filter-btn" data-filter="Public Policy & Governance">Public Policy</button>
      <button class="filter-btn" data-filter="Leadership & Executive Coaching">Leadership</button>
      <button class="filter-btn" data-filter="Business & Management">Management</button>
      <button class="filter-btn" data-filter="AI, Tech & Data Analytics">Data & AI</button>
      <button class="filter-btn" data-filter="ESG, Climate & Sustainability">ESG & Climate</button>
      <button class="filter-btn" data-filter="Finance, Audit & Governance">Finance & Audit</button>
      <button class="filter-btn" data-filter="HR & Operations">HR & Operations</button>
      <button class="filter-btn" data-filter="Project Management & M&E">Project Mgmt & M&E</button>
      <button class="filter-btn" data-filter="Marketing & Communications">Marketing</button>
    </div>

    <div class="course-list reveal reveal-delay-2" id="course-list-container">
      ${CourseCatalogue.map(course => `
        <div class="course-item" data-category="${course.category}">
          <div class="course-header">
            <h3 class="course-title">${course.title}</h3>
            <div class="course-meta">
              <span>${course.duration}</span>
              <span>${course.level}</span>
            </div>
          </div>
          <p class="course-desc">${course.description}</p>
        </div>
      `).join('')}
    </div>
  </div>
  <script>
    setTimeout(() => {
      const filters = document.querySelectorAll('.filter-btn');
      const items = document.querySelectorAll('.course-item');
      
      filters.forEach(btn => {
        btn.addEventListener('click', (e) => {
          filters.forEach(f => f.classList.remove('active'));
          e.target.classList.add('active');
          const category = e.target.getAttribute('data-filter');
          
          items.forEach(item => {
            if (category === 'all' || item.getAttribute('data-category') === category) {
              item.style.display = 'block';
            } else {
              item.style.display = 'none';
            }
          });
        });
      });
    }, 100);
  </script>
</section>
`,

team: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">Our Team</div>
      <h2 class="section-title">The <span class="gold">Oracle</span> Network</h2>
      <p class="section-subtitle">Our consultants bring deep government, technology, and sector experience to every engagement across East Africa and the SADC region.</p>
    </div>
    <div class="team-grid">
      <div class="team-card reveal reveal-delay-1">
        <div class="team-avatar">PO</div>
        <h4>Policy Experts</h4>
        <div class="role">Research & Analysis</div>
        <p class="bio">Specialists in evaluating, reviewing, and reforming existing policies.</p>
      </div>
      <div class="team-card reveal reveal-delay-2">
        <div class="team-avatar">AI</div>
        <h4>Tech & AI Specialists</h4>
        <div class="role">Digital Transformation</div>
        <p class="bio">Guiding organisations through drafting and adopting practical AI policies.</p>
      </div>
      <div class="team-card reveal reveal-delay-3">
        <div class="team-avatar">ES</div>
        <h4>ESG & Climate Advisors</h4>
        <div class="role">Sustainability</div>
        <p class="bio">Experts in climate risk management and renewable energy transition.</p>
      </div>
      <div class="team-card reveal reveal-delay-4">
        <div class="team-avatar">LD</div>
        <h4>Leadership Coaches</h4>
        <div class="role">Capacity Building</div>
        <p class="bio">Executive trainers upskilling public and private sector teams.</p>
      </div>
    </div>
  </div>
</section>
`,

contact: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header reveal">
      <div class="section-label">Get In Touch</div>
      <h2 class="section-title">Let's Work <span class="gold">Together</span></h2>
      <p class="section-subtitle">Briefly describe your challenge, project, or question...</p>
    </div>
    <div class="contact-grid">
      <div>
        <div class="contact-info-cards">
          <div class="contact-info-card reveal">
            <div class="contact-info-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
            <div><h4>Our Office</h4><p>Nairobi, Kenya<br>East Africa</p></div>
          </div>
          <div class="contact-info-card reveal reveal-delay-1">
            <div class="contact-info-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
            <div><h4>Email Us</h4><p>info@policy.co.ke</p></div>
          </div>
          <div class="contact-info-card reveal reveal-delay-2">
            <div class="contact-info-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
            <div><h4>Call Us</h4><p><a href="tel:+254724890895">+254 724 890 895</a><br><a href="tel:+254726540446">+254 726 540 446</a><br>Mon-Fri, 8am - 6pm EAT</p></div>
          </div>
        </div>
      </div>
      <div class="contact-form reveal reveal-delay-1">
        <form id="contact-form" onsubmit="return false;">
          <div class="form-row">
            <div class="form-group"><label for="name">Full Name</label><input type="text" id="name" placeholder="Your name"></div>
            <div class="form-group"><label for="email">Email</label><input type="email" id="email" placeholder="your@email.com"></div>
          </div>
          <div class="form-group"><label for="org">Organization</label><input type="text" id="org" placeholder="Your organization"></div>
          <div class="form-group"><label for="service">Service Interest</label>
            <select id="service"><option value="">Select a service</option><option>Policy Research</option><option>Training Programs</option><option>Strategic Consultancy</option><option>Data & Analytics</option><option>Other</option></select>
          </div>
          <div class="form-group"><label for="message">Message</label><textarea id="message" placeholder="Briefly describe your challenge, project, or question..."></textarea></div>
          <button type="submit" class="btn-primary form-submit">Send Message →</button>
        </form>
      </div>
    </div>
  </div>
</section>
`,

blog: () => `
<section class="section" style="padding-top:140px">
  <div class="container">
    <div class="section-header center reveal">
      <div class="section-label">Blog</div>
      <h2 class="section-title">Policy <span class="gold">Perspectives</span></h2>
      <p class="section-subtitle">Expert commentary, analysis, and thought leadership on Africa's most pressing policy challenges.</p>
    </div>
    <div class="insights-grid">
      <div class="insight-card reveal reveal-delay-1">
        <div class="insight-image"><div class="insight-image-overlay">📝</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Opinion</span><span class="insight-date">May 18, 2026</span></div>
          <h3>Why Africa Needs Homegrown Policy Think Tanks Now More Than Ever</h3>
          <p>As global challenges intensify, African nations must develop indigenous policy research capacity to craft context-specific solutions rather than relying on externally designed frameworks.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-2">
        <div class="insight-image"><div class="insight-image-overlay">🌍</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Analysis</span><span class="insight-date">May 10, 2026</span></div>
          <h3>The Role of Data-Driven Policy Making in Kenya's Vision 2030</h3>
          <p>How data analytics and evidence-based approaches are reshaping Kenya's national development agenda and what other African countries can learn.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-3">
        <div class="insight-image"><div class="insight-image-overlay">🏛️</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Governance</span><span class="insight-date">Apr 28, 2026</span></div>
          <h3>Strengthening Democratic Institutions Through Policy Reform in East Africa</h3>
          <p>An examination of how targeted policy interventions can enhance transparency, accountability, and public trust in East African democracies.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-1">
        <div class="insight-image"><div class="insight-image-overlay">💡</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Innovation</span><span class="insight-date">Apr 15, 2026</span></div>
          <h3>AI and Public Policy: Preparing African Governments for the Fourth Industrial Revolution</h3>
          <p>Exploring the policy frameworks needed to harness artificial intelligence while mitigating risks across African economies and societies.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-2">
        <div class="insight-image"><div class="insight-image-overlay">🌱</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Sustainability</span><span class="insight-date">Mar 30, 2026</span></div>
          <h3>Green Growth Strategies: Balancing Economic Development and Environmental Stewardship</h3>
          <p>Policy pathways for African nations to pursue economic growth while committing to climate resilience and environmental sustainability.</p>
        </div>
      </div>
      <div class="insight-card reveal reveal-delay-3">
        <div class="insight-image"><div class="insight-image-overlay">📊</div></div>
        <div class="insight-body">
          <div class="insight-meta"><span class="insight-tag">Capacity Building</span><span class="insight-date">Mar 12, 2026</span></div>
          <h3>Building the Next Generation of African Policy Analysts</h3>
          <p>How targeted training programs and mentorship initiatives are creating a pipeline of skilled policy professionals across the continent.</p>
        </div>
      </div>
    </div>
    <div class="cta-banner reveal" style="margin-top:60px">
      <h2>Follow Us on <span class="gold">Social Media</span></h2>
      <p>Stay updated with our latest insights, events, and policy commentary.</p>
      <div style="display: flex; gap: 16px; justify-content: center; margin-top: 24px;">
        <a href="https://www.linkedin.com/company/102496873/" target="_blank" rel="noopener noreferrer" class="btn-primary" style="background: #0077b5; color: white;">Follow on LinkedIn</a>
        <a href="https://web.facebook.com/policy.oraclekenya" target="_blank" rel="noopener noreferrer" class="btn-primary" style="background: #1877f2; color: white;">Follow on Facebook</a>
      </div>
    </div>
  </div>
</section>
`

};
